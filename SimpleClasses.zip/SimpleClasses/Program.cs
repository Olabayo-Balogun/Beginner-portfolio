﻿using System;

namespace SimpleClasses {
    class Program {
        static void Main (string[] args) {
            Car MyCar = new Car ();
            MyCar.Make = "Toyota";
            MyCar.Model = "Tacoma";
            MyCar.Year = 2004;
            MyCar.Color = "Black";

            Console.WriteLine ("{0} {1} {2} {3}",
                MyCar.Make,
                MyCar.Model,
                MyCar.Year,
                MyCar.Color);
            Console.ReadLine ();

        }
    }

    class Car {
        public string Make (get; set;)
        public string Model { get; set; }
        public int Year { get; set; }
        public string Color { get; set; }

    }

}