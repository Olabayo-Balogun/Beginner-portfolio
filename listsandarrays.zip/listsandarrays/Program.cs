﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace listsandarrays
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] accountBalances = new int[10];

            accountBalances[0] = 100000;
            accountBalances[1] = 10000;
            accountBalances[2] = 90000;
            accountBalances[3] = 4000;
            accountBalances[4] = 1000000;
            accountBalances[5] = 80000;
            accountBalances[6] = 180000;
            accountBalances[7] = 1008000;
            accountBalances[8] = 300000;
            accountBalances[9] = 1200000;

            
            List<string> fruits = new List<string>();
            fruits.Add("mango");
            fruits.Add("orange");
            fruits.Add("apple");
            fruits.Add("pineapple");

            Console.WriteLine (fruits[0]);
            
        }
    }
}
