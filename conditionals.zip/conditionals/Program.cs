﻿using System;

namespace conditionals
{
    class Program
    {
        static void Main(string[] args)
        {
            int age = 0;
            Console.Write("Welcome to Olabayo's bar, how old are you?; ");
            age = int.Parse(Console.ReadLine());

            if(age >= 18)
            {
                Console.WriteLine("You are old enough to drink here, what would you like to drink? ");
            }
            else if(age < 11)
            {
                Console.WriteLine("Please wait here, we won't let you leave without your guardian");
            }
            else
            {
                Console.WriteLine("You are too young to drink, please leave");
            }
            
        }
    }
}
