﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace loops
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> attendees = new List<string> ();  

            string input = "";

            while (input != "END")
            {
                Console.Write ("Enter student name:");
                input = Console.ReadLine ();
                
                if (input = "END")
                {
                    break;
                }
             
                attendees.Add (input);
            }
            
            Console.WriteLine ("\nAttendees added successfully, names are shown below\n");
            
            for (int i = 0; i < attendees.Count (); i++)
            {
                Console.WriteLine (attendees[i]);
            }


        }
    }
}
