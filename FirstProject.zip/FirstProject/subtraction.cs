using System;

namespace subtraction
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello from Bayo first program");
        }
    }
}
